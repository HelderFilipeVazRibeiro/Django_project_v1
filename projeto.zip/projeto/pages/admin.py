from django.contrib import admin
from .models import MinhaImagem

admin.site.register(MinhaImagem)